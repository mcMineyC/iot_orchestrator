import os from "os";
import fs from "fs";
import mdnsLib from "multicast-dns";
const mdns = mdnsLib();
class MdnsService {
  //constructor(name, port) {
  //  this.name = name;
  //  this.port = port;
  //  this.ip = getLocalIP();
  //  this.services = [
  //    {
  //      name: this.name,
  //      port: this.port,
  //      ip: this.ip
  //    }
  //  ]
  //}
  constructor(service) {
    this.name = service.name;
    this.port = service.port;
    //this.ip = getLocalIP(); // Depreciated in favor of multiple interface support
    // service.ip = this.ip;
    this.services = [service];
  }
  advertise() {
    // if (!this.ip) {
    //   throw new Error("Unable to find a local IP address.");
    // }
    var services = this.services;
    var serviceDefinitionToResponse = this.serviceDefinitionToResponse;
    console.log(
      `Advertising service '${this.name}._tcp.local' on ${this.ip}:${this.port}...`,
    );
    mdns.on("query", function (query, rinfo) {
      // console.log("Rinfo", rinfo)
      // console.log(query.questions)
      // fs.writeFileSync("./mdnsMessage.json", JSON.stringify(query,null,2))
      if (
        query.questions.some(
          (q) =>
            services.filter((x) => q.name == `_${x.name}._tcp.local`).length > 0,
        )
      ) {
        console.log("Received a query");
        // Respond to the query with service details
        let answers = [];
        services
          .filter((x) => query.questions[0].name == `_${x.name}._tcp.local`)
          .forEach((service) => {
            let answer = serviceDefinitionToResponse(service, rinfo.address);
            answers = answers.concat(answer);
          });
        mdns.respond({
          answers: answers,
        });
        console.log(JSON.stringify(answers, null, 2));
        console.log(
          `Responded with service details for ${this.name} at ${this.ip}:${this.port}`,
        );
      }
    });
  }
  addService(service) {
    if (!service.name || !service.port) {
      throw new Error("Service must have a name and port.");
    }
    if (!service.ip) {
      service.ip = this.ip;
    }
    this.services.push(service);
    console.log(
      `Added service ${service.name} at ${service.ip}:${service.port}`,
    );
  }
  serviceDefinitionToResponse(definition, requestingAddress) {
    console.log(definition);
    var hostname = os.hostname();
    definition.ip = getLocalIP(requestingAddress)
    return [

      //Proper RFC-compliant advertisement
      {
        name: `_${definition.name}._tcp.local`,
        type: "PTR",
        ttl: 120,
        data: `${definition.instance}._${definition.name}._tcp.local`,
        target: definition.ip,
        // target: `${hostname}.local`,  // Use hostname instead of IP
      },
      {
        name: `${definition.instance}._${definition.name}._tcp.local`,
        type: "SRV",
        ttl: 120,
        data: {
          priority: 0,  // Changed from 10 to 0 (default priority)
          weight: 0,
          port: definition.port,
          // target: definition.ip,
          target: `${hostname}.local`,  // Use hostname instead of IP
        },
      },
      {
        name: `${hostname}.local`,
        type: "A",
        ttl: 120,
        data: definition.ip,
      },

      //Basic backward-compatible advertisement
      {
        name: `_${definition.name}._tcp.local`,
        type: "TXT", // TXT record with metadata about the service
        ttl: 120,
        data: [
          `ip=${definition.ip}`,
          `port=${definition.port}`,
          `description=${definition.friendlyName || "No description"}`,
        ],
      },
    ];
  }

  stop() {
    mdns.destroy();
  }
}

function getLocalIP(matcher) { // Find IP address on same subnet as query (useful for multiple interfaces eg ethernet + Wifi)
  const networkInterfaces = os.networkInterfaces();
  let localIP = null;
  matcherParts = matcher.split(".").slice(0, -1); // chop off last segment, keeping subnet

  // Loop through network interfaces to find the first non-internal IPv4 address
  for (const interfaceName in networkInterfaces) {
    for (const interfaceInfo of networkInterfaces[interfaceName]) {
      if (interfaceInfo.family === "IPv4" && !interfaceInfo.internal) {
        if(interfaceInfo.address.split(".").slice(0,-1) == matcherParts){
          localIP = interfaceInfo.address;
          break;
        }
      }
    }
    if (localIP) break; // Stop once we find the first valid IP
  }

  return localIP;
}

export default MdnsService;
